﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Checkers.UI;
using Checkers.Logic;

namespace Checkers
{
    public class Program
    {

        static void Main()
        {
            Game game1 = new Game();
            game1.Run();
        }
    }
}
