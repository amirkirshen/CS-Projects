﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleUI
{
    class Program
    {
        public static void Main()
        {
            UIManager manager = new UIManager();

            manager.RunUI();
        }


    }
}
